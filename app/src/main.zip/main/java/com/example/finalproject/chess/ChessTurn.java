package com.example.finalproject.chess;

public class ChessTurn {
    public int x_start, y_start, x_finish, y_finish;

    public ChessTurn(int x1,int y1,int x2,int y2){
        x_start = x1;
        y_start = y1;
        x_finish = x2;
        y_finish = y2;
    }
}