package com.example.finalproject.chess;

public enum Figure {
    Empty,
    White_Pawn,
    White_Rook,
    White_Knight,
    White_Bishop,
    White_King,
    White_Queen,
    Black_Pawn,
    Black_Rook,
    Black_Knight,
    Black_Bishop,
    Black_King,
    Black_Queen
}
