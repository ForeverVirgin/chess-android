package com.example.finalproject.chess;

public enum Players {
    Black,
    White
}
